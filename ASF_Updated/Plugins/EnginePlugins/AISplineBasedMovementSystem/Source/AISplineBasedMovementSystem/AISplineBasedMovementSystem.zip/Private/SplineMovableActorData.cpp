#include "SplineMovableActorData.h"

FSplineMovableActorData::FSplineMovableActorData() {
}

