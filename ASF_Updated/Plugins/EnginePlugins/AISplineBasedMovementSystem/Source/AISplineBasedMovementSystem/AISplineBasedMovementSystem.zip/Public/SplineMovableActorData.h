#pragma once
#include "CoreMinimal.h"
#include "SplineMovableActorData.generated.h"

USTRUCT(BlueprintType)
struct FSplineMovableActorData {
    GENERATED_BODY()
public:
    AISPLINEBASEDMOVEMENTSYSTEM_API FSplineMovableActorData();
};

